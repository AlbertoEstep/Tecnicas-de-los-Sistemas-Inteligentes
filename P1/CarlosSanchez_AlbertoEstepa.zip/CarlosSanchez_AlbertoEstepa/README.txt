
TÉCNICAS DE LOS SISTEMAS INTELIGENTES - PRÁCTICA 1
Alberto Estepa Fernández
Carlos Santiago Sánchez Muñoz

- La memoria es el documento P1.pdf

- la carpeta practica_busqueda es el paquete practica_busqueda donde esta programado nuestro Agent el cual hereda de BaseAgent y por eso se incluyen los ficheros del wrapper del tutorial 2.

- Por último proporcionámos 4 mapas en la carpeta maps, en los que hemos considerado algunos casos extremos:
		boulderdash_lvl5.txt: para liberar gemas tirando rocas por abajo
		boulderdash_lvl6.txt: nivel con los monstruos sueltos. No hay tierra por lo que habrá una lluvia de rocas.
		boulderdash_lvl7.txt: liberar gemas tirando rocas por la izquierda
		boulderdash_lvl8.txt: liberar gemas tirando rocas por la derecha con monstruo inclusive

